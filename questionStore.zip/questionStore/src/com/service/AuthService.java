
package com.service;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.model.User;
import com.model.ExamModify;
import com.model.QuesAdding;
import com.model.Register;
 
public class AuthService {
 
    private HibernateTemplate hibernateTemplate;
   
 
    private AuthService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }
 
    @SuppressWarnings( { "unchecked", "deprecation" } )
    public String findUser(String uname, String upwd) {
   
        String returnType = new String("Invalid");
        //String sqlQuery = "from User where name='"+uname + "' and password='"+upwd+"'";
        String sqlQuery = "from Register u where u.firstname=? and u.psw=?";
        //String sqlQuery = "from register";
        System.out.println("In the authentication service...user entered data " + uname + " pwd "+upwd);
        String emp_type=new String("");
        try {
            List<Register> userObj = (List) hibernateTemplate.find(sqlQuery, uname, upwd);
            
            if(userObj != null)
            {
            	System.out.println("userObject is not null... ");
                for (Register obj : userObj)
                {
                    System.out.println("Id "+obj.getId() + 
                       " Name " + obj.getFirstname() + 
                       " Editor "+obj.getPsw());
                    emp_type = obj.getEmp_type();
                    returnType = emp_type;
                }

            }          
            
            
            if(userObj != null && userObj.size() > 0) {
                //log.info("Id= " + userObj.get(0)).getId() + ", Name= " + userObj.get(0).getName() + ", Password= " + userObj.get(0).getPassword());
            	return returnType;
            	
            }
        } catch(Exception e) {
        	returnType = "Invalid";
                 
        }
        return returnType;
    }
 
  
	public boolean registeruser(Register reg) {
		// TODO Auto-generated method stub
		System.out.println("Before database");
		
		
        Session session = hibernateTemplate.getSessionFactory().openSession();
        session.save(reg);
		//hibernateTemplate.save(reg);
		
		System.out.println("After database");
		return true;
	}
	
	
	public List<QuesAdding> getAllQuesAdding() {
		
		System.out.println("In getAllQuesAdding...");
		//System.out.println("Session data "+sessionFactory.getCurrentSession());
		//List <QuesAdding> lst = (sessionFactory.getCurrentSession().createQuery("from QuesAdding")).list();
		String sqlQuery = new String("from QuesAdding");
		System.out.println("HibernateTemplate "+hibernateTemplate);
		List<QuesAdding> userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery);
        
        if(userObjLst != null)
        {
        	System.out.println("userObject is not null... ");
        }   
				
        return userObjLst;
	} 
	
	
	 
	public void addQuesAdding(QuesAdding ques) {
		     	
		Session session = hibernateTemplate.getSessionFactory().openSession();
		System.out.println("Current session "+session);
		
		 String sqlQuery1 = "INSERT INTO Question (mark,question,a,b,c,d,selection,skill,answer,level) VALUES  (?,?,?,?,?,?,?,?,?,?)";
		 
		 session.beginTransaction();

		 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
		insertQuery.setParameter(0, ques.getMark());
		insertQuery.setParameter(1,ques.getQuestion());
		insertQuery.setParameter(2,ques.getA());
		insertQuery.setParameter(3,ques.getB());
		insertQuery.setParameter(4,ques.getC());
		insertQuery.setParameter(5,ques.getD());
		insertQuery.setParameter(6,ques.getSelection());
		insertQuery.setParameter(7,ques.getSkill());
		insertQuery.setParameter(8,ques.getAnswer());
		insertQuery.setParameter(9,ques.getLevel());
		 
		 insertQuery.executeUpdate();
		 session.getTransaction().commit();
	}
	
	public void deleteQuesAdding(Integer id) {
		 
		hibernateTemplate.bulkUpdate("DELETE FROM QuesAdding where id ="+id);
		  
 	}
	
	public QuesAdding getQuesAdding(int id) {
		String sqlQuery = new String("from QuesAdding where id = ?");
		@SuppressWarnings("unchecked")
		List<QuesAdding> userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery,id);
		
		QuesAdding QuesObj=null;
		for (QuesAdding QuesObj1 : userObjLst)
		{
			  QuesObj = QuesObj1;
		}
		return QuesObj;

		//return (QuesAdding) sessionFactory.getCurrentSession().get(QuesAdding.class,id);
	}
	
	public QuesAdding updateQuesAdding(QuesAdding ques) {
		//sessionFactory.getCurrentSession().update(ques);
		Session session = hibernateTemplate.getSessionFactory().openSession();
		System.out.println("Current session "+session);
		
		 String sqlQuery1 = "update emp.Question SET a = ?,b=?,c=?,d=?,mark=?,question=?,selection=?,skill=?,answer=?,level=? WHERE id=?";
		 
		 session.beginTransaction();

		 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
		insertQuery.setParameter(0, ques.getA());
		
		insertQuery.setParameter(1,ques.getB());
		insertQuery.setParameter(2,ques.getC());
		insertQuery.setParameter(3,ques.getD());
		insertQuery.setParameter(4,ques.getMark());
		insertQuery.setParameter(5,ques.getQuestion());
		insertQuery.setParameter(6,ques.getSelection());
		insertQuery.setParameter(7,ques.getSkill());
		insertQuery.setParameter(8,ques.getAnswer());
		insertQuery.setParameter(9,ques.getLevel());
		insertQuery.setParameter(10,ques.getId());
		 
		 insertQuery.executeUpdate();
		 session.getTransaction().commit();
		 
		
		return ques;
	}

//hibernateTemplate.save(ques, ques.getId(),ques.getMark(),ques.getQuestion(),ques.getA(),ques.getB(),ques.getC(),ques.getD(),ques.getSelection(),ques.getSkill(),ques.getAnswer(),ques.getLevel() );
public List<ExamModify> getAllExamModify() {
	
	System.out.println("In getAllExamModify...");
	//System.out.println("Session data "+sessionFactory.getCurrentSession());
	//List <QuesAdding> lst = (sessionFactory.getCurrentSession().createQuery("from QuesAdding")).list();
	String sqlQuery = new String("from ExamModify");
	System.out.println("HibernateTemplate "+hibernateTemplate);
	List<ExamModify> userObjLst = (List<ExamModify>) hibernateTemplate.find(sqlQuery);
    
    if(userObjLst != null)
    {
    	System.out.println("userObject is not null... ");
    }   
			
    return userObjLst;
} 


 
public void addExamModify(ExamModify exam) {
	     	
	Session session = hibernateTemplate.getSessionFactory().openSession();
	System.out.println("Current session "+session);
	
	 String sqlQuery1 = "INSERT INTO Examination (exam_name,skill,level) VALUES  (?,?,?)";
	 
	 session.beginTransaction();

	 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
	insertQuery.setParameter(0, exam.getExam_name());
	
	insertQuery.setParameter(1,exam.getSkill());
	
	insertQuery.setParameter(2,exam.getLevel());
	 
	 insertQuery.executeUpdate();
	 session.getTransaction().commit();
}

public void deleteExamModify(Integer id) {
	 
	hibernateTemplate.bulkUpdate("DELETE FROM ExamModify where id ="+id);
	  
	}

public ExamModify getExamModify(int id) {
	String sqlQuery = new String("from ExamModify where id = ?");
	@SuppressWarnings("unchecked")
	List<ExamModify> userObjLst = (List<ExamModify>) hibernateTemplate.find(sqlQuery,id);
	
	ExamModify ExamObj=null;
	for (ExamModify ExamObj1 : userObjLst)
	{
		  ExamObj = ExamObj1;
	}
	return ExamObj;

	//return (QuesAdding) sessionFactory.getCurrentSession().get(QuesAdding.class,id);
}

public ExamModify updateExamModify(ExamModify exam) {
	//sessionFactory.getCurrentSession().update(ques);
	Session session = hibernateTemplate.getSessionFactory().openSession();
	System.out.println("Current session "+session);
	
	 String sqlQuery1 = "update emp.Examination SET exam_name=?,skill=?,level=? WHERE id=?";
	 
	 session.beginTransaction();

	 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
	;
	insertQuery.setParameter(0,exam.getExam_name());
	insertQuery.setParameter(1,exam.getSkill());
	
	insertQuery.setParameter(2,exam.getLevel());
	insertQuery.setParameter(3,exam.getId());
	 
	 insertQuery.executeUpdate();
	 session.getTransaction().commit();
	 
	
	return exam;
}
}
