package com.service;

/*import java.util.List;

import com.model.ExamModify; 

public interface ExamModifyService {
	public void addExamModify(ExamModify exam);

	public List<ExamModify> getAllExamModify();

	public void deleteExamModify(Integer exam_id);

	public ExamModify getExamModify(int exam_id);

	public ExamModify updateExamModify(ExamModify exam);

}
*/
import java.util.List;

import com.model.ExamModify;

public interface ExamModifyService {
	
	public void addExamModify(ExamModify exam);

	public List<ExamModify> getAllEmployees();

	public void deleteExamModify(Integer Id);

	public ExamModify getExamModify(int id);

	public ExamModify updateExamModify(ExamModify exam);
}
