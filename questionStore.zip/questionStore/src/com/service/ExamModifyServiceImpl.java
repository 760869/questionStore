package com.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.ExamModifyDAO;
import com.model.ExamModify;

@Service
@Transactional
public class ExamModifyServiceImpl implements ExamModifyService {

	@Autowired
	private ExamModifyDAO examModifyDAO;

	@Transactional
	public void addExamModify(ExamModify exam1) {
		examModifyDAO.addExamModify(exam1);
	}

	@Transactional
	public List<ExamModify> getAllExamModify() {
		return examModifyDAO.getAllExamModify();
	}

	@Transactional
	public void deleteExamModify(Integer examId) {
		examModifyDAO.deleteExamModify(examId);
	}

	public ExamModify getExamModify(int examid) {
		return examModifyDAO.getExamModify(examid);
	}

	public ExamModify updateExamModify(ExamModify exam1) {
		// TODO Auto-generated method stub
		return examModifyDAO.updateExamModify(exam1);
	}

	public void setExamModifyDAO(ExamModifyDAO examModifyDAO) {
		this.examModifyDAO = examModifyDAO;
	}

}
