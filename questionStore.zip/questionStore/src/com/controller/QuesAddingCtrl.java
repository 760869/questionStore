package com.controller;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Employee;
import com.model.ExamModify;
import com.model.QuesAdding;
import com.service.AuthService;
import com.service.ExamModifyService;
import com.service.QuesAddingService;
import com.service.QuesAddingServiceImpl;

@Component
@Controller
@RequestMapping("/QuestionPaper")
public class QuesAddingCtrl {

	@Autowired
	private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.


	public QuesAddingCtrl() {
		System.out.println("QuesAddingCtrl()");
	}

	@Autowired
	private QuesAddingService quesAddingService;

	@RequestMapping(value = "/AdminHome")
	public ModelAndView listQuesAdding(ModelAndView model) throws IOException {
		System.out.println("Inside /AdminHome of controller...");

		List<QuesAdding> listQuesAdding =  authenticateService.getAllQuesAdding();


		for (QuesAdding e : listQuesAdding)
		{
			System.out.println(e.getId());
		}
		model.addObject("listQuesAdding", listQuesAdding);
		model.setViewName("home");
		return model;
	}

	@RequestMapping(value = "/newQuesAdding", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		QuesAdding ques = new QuesAdding();
		model.addObject("ques", ques);
		model.setViewName("QuesAddingForm");
		return model;

		/*System.out.println("Inside /newQuesAdding");
		Employee employee = new Employee();
		model.addObject("employee", employee);
		model.setViewName("EmployeeForm");
		return model;*/

	}

	@RequestMapping(value = "/saveQuesAdding", method = RequestMethod.POST)
	public ModelAndView saveQuesAdding(@ModelAttribute QuesAdding ques) {
		System.out.println("Id before saving..."+ques.getQuestion());

		if (ques.getId() == 0) {
			// if employee id is 0 then creating the ques other updating the employee
			authenticateService.addQuesAdding(ques);

		} else {
			authenticateService.updateQuesAdding(ques);
		}
		return new ModelAndView("redirect:/QuestionPaper/AdminHome");
	}

	@RequestMapping (value="/SaveEditQuestion", method=RequestMethod.GET)
	public ModelAndView SaveEdit(@ModelAttribute QuesAdding ques)
	{
		System.out.println("Inside /SaveEdit...");
		return new ModelAndView("redirect:/QuestionPaper/AdminHome");
	}


	@RequestMapping(value = "/deleteQuesAdding", method = RequestMethod.GET)
	public ModelAndView deleteQuesAdding(HttpServletRequest request) {
		System.out.println("Inside /deleteQuesAdding...");
		int id = Integer.parseInt(request.getParameter("id"));

		authenticateService.deleteQuesAdding(id);
		return new ModelAndView("redirect:/QuestionPaper/AdminHome");
	}

	@RequestMapping(value = "/editQuesAdding", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));

		System.out.println("In /editQuesAdding..");

		QuesAdding ques = authenticateService.getQuesAdding(id);
		ModelAndView model = new ModelAndView("QuesAddingForm");
		model.addObject("ques", ques);

		return model;
	}

	@ModelAttribute("levelList")
	public Map<String, String> getLevelList() {
		Map<String, String> levelList = new HashMap<String, String>();
		levelList.put("Easy", "LEVEL-1");
		levelList.put("Medium", "LEVEL-2");
		levelList.put("Hard", "LEVEL-3");

		return levelList;
	}
	@ModelAttribute("answerList")
	public Map<String, String> getAnswerList() {
		Map<String, String> answerList = new HashMap<String, String>();
		answerList.put("A", "A");
		answerList.put("B", "B");
		answerList.put("C", "C");
		answerList.put("D", "D");

		return answerList;
	}

}
