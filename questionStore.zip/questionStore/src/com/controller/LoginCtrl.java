package com.controller;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.model.ExamModify; 
import com.model.QuesAdding;
import com.model.Register;
import com.service.AuthService;
import com.service.ExamModifyService;
import com.service.QuesAddingService;

import antlr.collections.List;
 
@Controller
@RequestMapping("/user")

public class LoginCtrl {
	 @Autowired
	    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
	 
	     
	 
	    // Checks if the user credentials are valid or not.
	    @RequestMapping(value = "/validate", method = RequestMethod.POST)
	    public ModelAndView validateUsr(@RequestParam("username")String username, @RequestParam("password")String password) {
	        String msg = "";
	        String empType = authenticateService.findUser(username, password);
	        
	       
	        
	 
	        if(!empType.equals("Invalid")) {
	            msg = "Welcome " + username + "!";
	            
	            if (empType.equals("A"))	            
	               return new ModelAndView("admin", "output", msg);
	            else
	              return new ModelAndView("result", "output", msg);
	        } else {
	            msg = "Invalid credentials";
	            return new ModelAndView("invalid", "output", msg);
	        }
	 
	     
	    }
	    
	    //testing for register
	    
	    @RequestMapping(value = "/registerlink")
		public ModelAndView redirectregister()
		{
			System.out.println("In the /registerlink");
			return new ModelAndView("register","User_Type","User");
	    	//return new ModelAndView("register");
		}
		
		 @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
		    public ModelAndView RegisterUsr(@RequestParam("firstname")String firstname, @RequestParam("lastname")String lastname,@RequestParam("email")String email,@RequestParam("psw")String psw,@RequestParam("emp_type")String emp_type) {
		       
		     System.out.println("Inside /registerProcess...");	
			 System.out.println("Emp type "+emp_type);
		    	Register reg = new Register();
		        reg.setEmail(email);
		        reg.setFirstname(firstname);
		        reg.setLastname(lastname);
		        reg.setPsw(psw);
		        reg.setEmp_type(emp_type);		       
		      
		        boolean isValid = authenticateService.registeruser(reg);
		             
		 
		        if(isValid) {
		        	return new ModelAndView("index");
		        } else {
		        	return new ModelAndView("register");
		        }
		 
		        
		    }
		 
		 
		 //EmployeeType
		 
		 @RequestMapping(value = "/SignupAdmin")
			public ModelAndView AdminReg()
			{
				System.out.println("In the /registerlink");
		    	return new ModelAndView("register","User_Type","Admin");
			}
		
	}


