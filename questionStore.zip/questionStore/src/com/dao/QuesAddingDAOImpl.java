
package com.dao;

import java.util.List;



import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.QuesAdding;

@Repository
@Transactional(readOnly = false)
public class QuesAddingDAOImpl implements QuesAddingDAO{
	

	private HibernateTemplate hibernateTemplate;

 	
	public void addQuesAdding(QuesAdding ques) {
		//sessionFactory.getCurrentSession().saveOrUpdate(ques);
		
		hibernateTemplate.save(ques);
	}

	@Transactional(readOnly = false)
	public List<QuesAdding> getAllQuesAdding() {
		
		System.out.println("In getAllEmployees...");
		//System.out.println("Session data "+sessionFactory.getCurrentSession());
		//List <QuesAdding> lst = (sessionFactory.getCurrentSession().createQuery("from QuesAdding")).list();
		String sqlQuery = new String("from QuesAdding");
		System.out.println("HibernateTemplate "+hibernateTemplate);
		List<QuesAdding> userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery);
        
        if(userObjLst != null)
        {
        	System.out.println("userObject is not null... ");
        }   
				
        return userObjLst;
	} 
	@Transactional(readOnly = false)

	public void deleteQuesAdding(Integer id) {
 
		hibernateTemplate.bulkUpdate("DELETE FROM QuesAdding where id ="+id);
		  
 	}

	public QuesAdding getQuesAdding(int id) {
		String sqlQuery = new String("from QuesAdding where id = ?");
		@SuppressWarnings("unchecked")
		List<QuesAdding> userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery,id);
		
		QuesAdding QuesObj=null;
		for (QuesAdding QuesObj1 : userObjLst)
		{
			  QuesObj = QuesObj1;
		}
		return QuesObj;

		//return (QuesAdding) sessionFactory.getCurrentSession().get(QuesAdding.class,id);
	}

	public QuesAdding updateQuesAdding(QuesAdding ques) {
		//sessionFactory.getCurrentSession().update(ques);
		System.out.println("In Update...updateQuesAdding()");
		
		String sqlQuery = new String("UPDATE QuesAdding SET ");
		hibernateTemplate.saveOrUpdate(ques);
		
		return ques;
	}
	
	

}

