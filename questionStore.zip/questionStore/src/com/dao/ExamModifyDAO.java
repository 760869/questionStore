package com.dao;
import java.util.List;


import com.model.ExamModify;


public interface ExamModifyDAO {
	public void addExamModify(ExamModify exam);

	public List<ExamModify> getAllExamModify();

	public void deleteExamModify(Integer id);

	public ExamModify updateExamModify(ExamModify exam);

	public ExamModify getExamModify(int id);
	

}
