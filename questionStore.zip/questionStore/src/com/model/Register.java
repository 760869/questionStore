package com.model;
import java.io.Serializable;

public class Register implements  Serializable{
	private static final long serialVersionUID = 5L;
	

    
	 
    private int id;
    
    
    private String firstname;
    
    
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String lastname;
    
     
    private String email;
    
    
    private String psw;
    
    private String emp_type;
    
    
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getEmp_type() {
		return emp_type;
	}
	public void setEmp_type(String emp_type) {
		this.emp_type = emp_type;
	}

}
